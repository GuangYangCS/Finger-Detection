#include "opencv2/opencv.hpp"
#include "opencv2/highgui.hpp"
#include <iostream>
#include <fstream>
#include <string>
#include "dirent.h"
using namespace cv;
using namespace std;

/*
  min embedding of  image of size rxc into size r+dr x c+dc,
  so that (c+dc)/(r+dr) = q

  if dr=0, c+dc = qr, dc = qr - c. This works if dc>=0.
  Otherwise: dc=0, (r+dr)q = c, dr = c/q - r
 */

Vec3b borderColor(const Mat &img) {
  int sum_r=0, sum_g=0, sum_b=0;
  int rows = img.rows;
  int cols = img.cols;
  Vec3b cpixel;
  for(int i = 0 ; i < rows ; i++) {
    cpixel = img.at<Vec3b>(i,0);
    sum_b += cpixel.val[0];
    sum_g += cpixel.val[1];
    sum_r += cpixel.val[2];

    cpixel = img.at<Vec3b>(i,cols-1);
    sum_b += cpixel.val[0];
    sum_g += cpixel.val[1];
    sum_r += cpixel.val[2];
  }
  for(int j = 1 ; j < cols-1 ; j++) {
    cpixel = img.at<Vec3b>(0,j);
    sum_b += cpixel.val[0];
    sum_g += cpixel.val[1];
    sum_r += cpixel.val[2];

    cpixel = img.at<Vec3b>(rows-1,j);
    sum_b += cpixel.val[0];
    sum_g += cpixel.val[1];
    sum_r += cpixel.val[2];
  }
  double av_r = (double)sum_r/(2*rows + 2*cols - 4);
  double av_g = (double)sum_g/(2*rows + 2*cols - 4);
  double av_b = (double)sum_b/(2*rows + 2*cols - 4);

  double gray = 0.3*av_r + 0.6*av_g + 0.1*av_b;
  if(gray < 127) return(Vec3b(0,0,0));
  else return(Vec3b(255,255,255));
}

void embedColor(const Mat &small, Mat &big) {
  Vec3b cpixel = borderColor(small);
  big = cpixel;
  int dx = big.cols - small.cols;
  int dy = big.rows - small.rows;
  // src.copyTo(dst(Rect(left, top, src.cols, src.rows)));}
  small.copyTo(big(Rect(dx/2, dy/2, small.cols, small.rows)));
}

int borderGray(const Mat &img) {
  int sum = 0;
  int rows = img.rows;
  int cols = img.cols;
  for(int i = 0 ; i < rows ; i++)
    sum += img.at<uchar>(i,0) + img.at<uchar>(i,cols-1);
  for(int j = 1 ; j < cols-1 ; j++)
    sum += img.at<uchar>(0,j) + img.at<uchar>(rows-1,j);
  double average = (double)sum/(2*rows + 2*cols - 4);
  if(average < 127) return(0);
  else return(255);
}

void embedGray(const Mat &small, Mat &big) {
  int gpixel = borderGray(small);
  big = gpixel;
  int dx = big.cols - small.cols;
  int dy = big.rows - small.rows;
  // src.copyTo(dst(Rect(left, top, src.cols, src.rows)));}
  small.copyTo(big(Rect(dx/2, dy/2, small.cols, small.rows)));
}


void embed(const Mat &small, Mat &big) {
  // they have the same type
  if(small.type() == CV_8UC3) return(embedColor(small, big));
  else if(small.type() == CV_8UC1) return(embedGray(small, big));
  else {
    cerr << small.type() << " not a standard color/gray image type" << endl;
    return(embedColor(small, big));
  }
}


Mat pad(const Mat &img, double q) {
  int r = img.rows;
  int c = img.cols;

  double dr, dc;
  dc = q*r - c;
  if(dc >= 0) dr = 0;
  else {
    dc = 0;
    dr = c/q - r;
  }
  int rows = (int)((double) r + dr + 0.5);
  int cols = (int)((double) c + dc + 0.5);
  Mat big(rows, cols, img.type());
  embed(img, big);
  return(big);
}

string padded_name(string name) {
  int d = (int) name.rfind(".");
  int m = (int) name.rfind("-");
  int r = (m >= 1) ? m : d;
  r--;
  int s1 = (int) name.rfind("/");
  int s2 = (int) name.rfind("\\");
  int l = 0;
  if(s1 >= l) l = s1+1;
  if(s2 >= l) l = s2+1;
  string base = name.substr(l,r-l+1);

  return(base + "-" + "pad" + ".bmp");
}

Mat imread(string name) {
  Mat img = imread(name, CV_LOAD_IMAGE_UNCHANGED);
  if(img.empty() || (img.type()==CV_8UC1) || (img.type()==CV_8UC3) )
    return(img);
  else if(img.type()==CV_8UC4) {
    Mat dst;
    cvtColor(img,dst,CV_BGRA2BGR);
    return(dst);
  }
  else {
    cerr << "Unrecognized image type " << img.type() << endl;
    return(Mat());
  }
}


int main(int argc, char** argv) {
  // read args: path w h
  int nargs = 3;
  String path = "";
  int w=-1; int h=-1;
  int I = 1;
  while (I < argc-1) {
    if(string(argv[I]).compare("-path")==0)
      { path = argv[I+1]; I += 2; }
    else if(strcmp(argv[I], "-w")==0)
      { w = atoi(argv[I+1]); I += 2; }
    else if(strcmp(argv[I], "-h")==0)
      { h = atoi(argv[I+1]); I += 2; }
    else {
      cerr << "Unrecognized argument " << argv[I] << endl;
      I++;
    }
  }
  if(path.compare("")==0 || (w <= 0) || (h <= 0)) {
    cerr << argv[0] << " Expecting arguments: -path -w -h " << endl
	 << "Example: Pad -path ../posimages -w 10 -h 20" << endl
	 << "Example: Pad -path img.jpg -w 10 -h 20" << endl;
    return(-1);
  }

  double ratio = (double)w/(double)h;

  Mat one_image = imread(path);
  if(!one_image.empty()) {
    string name = padded_name(path.c_str());
    Mat padded = pad(one_image, ratio);
    imwrite(name, padded);
  }
  else { // folder
    DIR *dir = opendir(path.c_str());
    if(dir == NULL) {
      cerr << "Can't open folder " << path << endl;
      return(-1);
    }
    struct dirent *entry;
    while ((entry = readdir(dir)) != NULL) {
      string bare = string(entry->d_name);
      string img_name = path + '/' + bare;
      Mat img = imread(img_name);
      if(img.empty()) {} // cerr <<  img_name << " is skipped" << endl;
      else {
	string name = padded_name(img_name);
	Mat padded = pad(img, ratio);
	imwrite(name, padded);
      }
    }

    return 0;
  }
}
